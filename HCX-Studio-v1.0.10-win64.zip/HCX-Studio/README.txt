﻿=====================================================================
  HCX STUDIO v1.0.9  —  studio siaran langsung ringan untuk Windows
  (penerus HC7690 STUDIO; PRO gratis 30 hari -> versi Gratis / Pro)
  "Fitur canggih bukan cuma buat orang kaya."
=====================================================================

KEBUTUHAN SISTEM
----------------
- Windows 10 atau Windows 11, 64-bit.
- Microsoft Edge WebView2 Runtime. Sudah ada di Windows 11 dan hampir
  semua Windows 10 yang rutin di-update. Kalau belum ada, HCXStudio.exe
  memasangnya sendiri saat pertama dibuka (butuh internet sekali, ±2 MB
  pemasang + unduhan dari Microsoft). Tidak perlu Google Chrome lagi.
- RAM 4 GB (disarankan 8 GB), CPU dual-core atau lebih. Tanpa kartu grafis
  khusus pun jalan; GPU NVIDIA/Intel/AMD dipakai otomatis bila ada.
- ffmpeg.exe (sudah ada di ZIP ini) untuk LIVE & REKAM.
- Internet upload yang cukup untuk siaran (lihat bagian 5).

BARU DI v1.0.10
---------------
1. Video bisa digeser seperti aplikasi pemutar video: di panel Sumber, tiap
   sumber Video punya bar geser (lompat ke menit mana saja) plus tombol
   ⏪10 / 10⏩ untuk mundur / maju 10 detik.
2. Teks berjalan (running text) lebih mudah:
   - Satu baris = satu berita. Tekan Enter untuk berita berikutnya, pemisah
     (• | ★ ◆ —) dipasang otomatis.
   - Kecepatan pakai geseran (Sangat lambat … Sangat cepat), tombol ⏸ Jeda,
     arah ke kiri / ke kanan, ukuran huruf, tebal / tipis.
   - Tombol "⬇ Bawah layar" / "⬆ Atas layar" dan geseran Tinggi bar.
3. Transisi baru + T-bar (tuas transisi seperti vMix):
   - Pilih efek di bawah tombol transisi: Fade, Wipe (4 arah), Slide, Push,
     Zoom, Iris (lingkaran), Dip ke hitam, Dip ke putih. Tombol, Spasi, remote
     HP dan T-bar memakai efek yang dipilih.
   - T-bar: tarik tuas pelan-pelan untuk transisi manual. Sampai ujung =
     selesai; tarik balik untuk transisi berikutnya.
   - Versi Gratis: Cut, Fade dan T-bar. Efek lainnya fitur Pro.
4. Tips mic diam: jika mic hijau tetapi tidak ada suara, buka Windows Sound →
   mic → Properties → Advanced, hapus centang "Allow applications to take
   exclusive control of this device".

BARU DI v1.0.9
--------------
1. Perbaikan MIC tanpa suara: di beberapa PC, sumber Mic sudah hijau ● di
   panel Sumber tetapi meter di panel Audio diam dan suara mic tidak masuk
   ke LIVE / rekaman. Sekarang:
   - Mesin audio selalu boleh berbunyi tanpa klik (kebijakan autoplay
     WebView2), dan diaktifkan ulang setiap kali Anda klik / menekan tombol.
   - Bila audio masih belum aktif, panel Audio menampilkan "Audio belum
     aktif — klik di mana saja". Klik sekali, meter langsung bergerak.
   - Mic tidak lagi dipaksa stereo / 48 kHz (mengikuti perangkat; ffmpeg
     tetap mengirim 48 kHz).
   - Pemeriksa mic otomatis: bila ±3 detik setelah mic dinyalakan tidak ada
     sinyal sama sekali, HCX mencoba ulang dengan pengaturan standar. Bila
     masih diam, sumber Mic diberi tanda ⚠ (bukan hijau) dengan petunjuk:
     cek Windows Settings > Privasi & keamanan > Mikrofon > "Izinkan
     aplikasi desktop mengakses mikrofon", pastikan mic tidak di-mute /
     dipakai aplikasi lain (mode eksklusif), atau pilih perangkat mic lain.
     Tanda ⚠ hilang sendiri begitu suara mic masuk. Detail diagnosa ada di
     tombol "Log" di bawah layar.

BARU DI v1.0.8
--------------
1. Model baru GRATIS + PRO (freemium):
   - Pertama kali dibuka: PRO GRATIS 30 HARI (dulu 7 hari) dengan semua
     fitur. PC yang sudah memakai versi lama tetap dihitung dari tanggal
     pertama dibuka, jadi mendapat sisa dari 30 hari.
   - Setelah 30 hari, setelah langganan Pro habis, atau bila jam komputer
     dimundurkan: aplikasi TIDAK terkunci lagi. Studio tetap terbuka sebagai
     VERSI GRATIS. Fitur Pro bertanda 🔒; klik untuk membeli / memasukkan
     kunci.
   - GRATIS: Kamera, Mic, Layar, Gambar/Logo, Video, Teks, Warna, PDF, Skor,
     Timer, Jam/Jadwal salat, 1 HP Cam, orientasi potret 9:16, rekaman,
     overlay komentar, lower-third gaya klasik (animasi Cut/Fade). Output
     maks. 720p (potret 720x1280), 1 tujuan siaran sekaligus, dan watermark
     kecil "HCX STUDIO" di pojok kanan bawah siaran & rekaman.
   - PRO: output 1080p sampai 4K tanpa watermark, multistream (beberapa
     tujuan sekaligus), LT Desain + animasi + tema lower-third, Virtual Set,
     Chroma key, Instant replay/slow-motion, Soundboard, Musik latar +
     ducking, Playlist video, Remote HP & tally, lebih dari 1 HP Cam, sensor
     wajah (blur/piksel) & stiker wajah, efek filter.
   - Project yang memakai fitur Pro tetap utuh di versi Gratis: lapisan /
     sumber Pro tampil 🔒 dan langsung jalan lagi setelah Pro aktif.
   - Badge 🔑 di kanan atas: "PRO GRATIS 12 hari", "PRO" atau "FREE".
     Panel 🔑 Lisensi menjelaskan beda Gratis vs Pro.

BARU DI v1.0.7
--------------
1. Suhu GPU NVIDIA kini terbaca juga di laptop yang nvidia-smi-nya
   melaporkan 0 °C (mis. GeForce 940MX Optimus). HCX membaca suhu lewat
   NVAPI dari driver NVIDIA, jalur yang sama dipakai GPU-Z dan
   MSI Afterburner. Kalau driver memang tidak punya data, tetap "—".
2. Baris kosong "GPU 0%" di detail Beban PC tidak ditampilkan lagi.

BARU DI v1.0.6
--------------
1. Pilihan kartu grafis — ⚙ Pengaturan -> "🎮 Kartu grafis":
   - "Ikut Windows" (bawaan), "Hemat daya (GPU terintegrasi)",
     "Performa tinggi (GPU NVIDIA/AMD)", atau pilih kartu tertentu
     menurut namanya (mis. "NVIDIA GeForce 940MX").
   - Tampilan studio digambar oleh proses WebView2 (msedgewebview2.exe),
     bukan oleh HCXStudio.exe. Karena itu mengatur HCXStudio.exe ke
     "High performance" di Pengaturan Grafis Windows tidak berpengaruh.
     Pilihan di HCX ini langsung mengatur WebView2 milik HCX.
   - Berlaku setelah HCX dibuka ulang (ada tombol "🔄 Buka ulang
     sekarang"; tidak bisa saat LIVE / REKAM).
   - Laptop dengan dua GPU (mis. Intel HD + GeForce) ditanya sekali saat
     pertama dibuka; disarankan "Performa tinggi". PC dengan satu GPU
     tidak ditanya.
   - Bila pilihan ini tidak berpengaruh di PC Anda: Pengaturan Windows ->
     Sistem -> Layar -> Grafis -> tambahkan msedgewebview2.exe ->
     "High performance".
2. Suhu GPU NVIDIA: nvidia-smi kini juga dicari di folder driver
   (DriverStore), tidak berhenti mencoba setelah gagal, dan suhu tidak
   hilang saat GPU sebentar menganggur. Bila kartu memang tidak
   melaporkan suhu, tetap tampil "—" (alasannya dicatat sekali di log).

BARU DI v1.0.5
--------------
1. Stiker ikut wajah — pilih lapisan kamera / HP Cam / video / gambar ->
   "🎭 Masker & sensor" -> "🙂 Sensor wajah otomatis" -> centang "Ikut
   wajah otomatis" -> pilih mode "Stiker". Setiap wajah yang terlihat
   ditutup gambar yang ikut bergerak, ikut membesar / mengecil, dan ikut
   miring saat kepala dimiringkan.
   - 10 stiker bawaan (buatan HCX STUDIO sendiri): topeng pesta, topeng
     hero, emoji senyum, emoji kacamata hitam, kucing, panda, bintang,
     kotak "SENSOR", kotak hitam, lingkaran blur.
   - "📁 Upload stiker sendiri": gambar PNG (boleh transparan), GIF
     (GIF animasi tetap bergerak) atau WebP. Tersimpan di project dan
     ikut di preset 💾 Setingan.
   - Pengaturan: Ukuran stiker, Geser kiri/kanan, Geser atas/bawah,
     Putar tambahan, Opasitas, "Ikut kemiringan kepala" (on/off) dan
     "Balik (cermin)". Gerakan dihaluskan seperti sensor blur/piksel.
   - Bila deteksi wajah tidak tersedia, stiker tidak ditampilkan (ada
     pesan di log) dan lapisan tetap tampil normal.
2. Indikator GPU diperbaiki untuk laptop dua GPU (mis. Intel HD +
   GeForce 940MX): nama GPU kini sesuai kartu yang benar-benar sedang
   dipakai, memori dan suhu diambil dari kartu yang sama. Suhu / VRAM
   yang tidak bisa dibaca (mis. kartu NVIDIA sedang tidur) tampil "—",
   bukan 0. Jendela detail menampilkan semua kartu grafis di PC beserta
   bebannya, dan HCX tidak lagi membangunkan kartu NVIDIA yang sedang
   tidur hanya untuk membaca suhu.

BARU DI v1.0.4
--------------
1. Sensor wajah otomatis (ikut wajah) — pilih lapisan kamera / HP Cam /
   video -> bagian "🎭 Masker & sensor" -> "🙂 Sensor wajah otomatis":
   centang "Ikut wajah otomatis", lalu setiap wajah yang terlihat di
   lapisan itu otomatis di-blur atau di-piksel (mosaik) dan sensornya
   ikut bergerak bersama wajah.
   - Pilihan: Blur / Piksel, bentuk Oval / Kotak, Kekuatan, "Lebihkan
     area (padding)", "Kehalusan gerak" (kotak tidak bergetar), "Tahan
     saat wajah hilang" (kotak terakhir tetap disensor sebentar bila
     deteksi terlewat), "Maks. wajah" (1-8), "Deteksi per detik".
   - Berjalan 100% offline di PC ini (tanpa internet, tidak ada gambar
     yang dikirim ke mana pun). Memakai GPU bila bisa, kalau tidak
     otomatis memakai CPU. Deteksi dijalankan ±12 kali per detik pada
     gambar kecil, di antaranya kotak bergerak halus -> tetap ringan di
     laptop (mis. GeForce 940MX / Intel HD).
   - Paling akurat untuk wajah yang cukup besar di layar (kamera depan,
     jarak 0,5-2 m). Untuk wajah kecil / jauh di video lebar, centang
     "Cari wajah kecil / jauh" (lebih berat).
   - Bila model deteksi gagal dimuat, muncul pesan dan lapisan tetap
     tampil seperti biasa (tanpa sensor wajah). Untuk area yang wajib
     tersensor, tetap pakai area sensor manual (kotak blur/piksel).
   Tersimpan di project dan di preset 💾 Setingan.
2. Indikator CPU / GPU / RAM di bar atas (di sebelah kbps / fps / drop /
   antrian): hijau di bawah 60%, kuning 60-85%, merah di atas 85%.
   Klik indikator -> jendela detail: grafik 60 detik terakhir, pemakaian
   HCX STUDIO dibanding seluruh PC, VRAM dan suhu GPU (bila kartu grafis
   mendukung, mis. NVIDIA dengan driver resmi). "—" berarti nilai itu
   tidak bisa dibaca di PC ini.
   Bila beban terus tinggi (±15 detik), muncul peringatan otomatis
   dengan saran: turunkan resolusi / fps, matikan "Kulit halus" atau
   sensor wajah, pakai encoder GPU, tutup aplikasi lain.
   GPU dibaca dari penghitung Windows (Windows 10 versi 1709 ke atas).

BARU DI v1.0.3
--------------
1. Efek filter per lapisan — pilih lapisan -> bagian "🎨 Efek filter":
   - Warna: Eksposur, Kecerahan, Kontras, Saturasi, Rona (hue), Suhu
     warna (hangat/dingin), Tint (hijau/magenta), Gamma.
   - Detail & efek: Blur, Pertajam, Kulit halus (beauty), Vignette,
     Grain film (bergerak seperti film).
   - Preset look sekali klik: Natural, Hangat, Dingin, Sinematik,
     Hitam Putih, Vintage, Cerah, Drama (lalu bisa diatur lagi).
   - Impor LUT (.cube, 3D, ukuran 17/32/33/65 dll.) dengan slider
     kekuatan. LUT disimpan di dalam project (ikut tersimpan di preset).
   - Centang "Aktif" untuk menyalakan/mematikan tanpa kehilangan
     setingan; "↺ Reset" menghapus semua efek. Klik ganda slider = 0.
   Berlaku di Preview, Program, siaran, rekaman dan output eksternal.
   Diproses di GPU (WebGL); kecerahan/kontras/saturasi/rona/blur saja
   memakai jalur paling ringan. Lapisan tanpa filter tidak menambah
   beban sama sekali. Di PC sangat lemah, pakai efek berat (kulit halus,
   LUT, grain) hanya di lapisan kamera utama.

BARU DI v1.0.2
--------------
1. Beli lisensi langsung online: di panel 🔑 Lisensi (dan layar aktivasi)
   tombol WhatsApp diganti tombol "🛒 Beli Lisensi". Klik -> halaman
   pembelian terbuka di browser dengan ID Mesin PC ini SUDAH TERISI.
   Pilih paket, bayar, kunci lisensi (HCX1-...) dikirim otomatis.
   Tombol "🔄 Perpanjang" muncul bila langganan tinggal 7 hari atau sudah
   habis. Mau tanya-tanya? Tetap ada tautan kecil "💬 Bantuan via WhatsApp"
   (0852-8875-3044).
2. Cek lisensi online: saat kunci diaktifkan, dan saat aplikasi dibuka
   (paling sering sekali sehari), HCX STUDIO menanyakan keabsahan kunci ke
   server lisensi. Kunci yang dicabut penjual atau terdaftar untuk PC lain
   otomatis dinonaktifkan (kembali ke uji coba / layar aktivasi) dengan
   pesan yang jelas. Tidak ada internet? Aplikasi tetap jalan normal
   (pemeriksaan di PC tetap berlaku) dan dicek ulang saat dibuka lagi.
3. Cek Update: ⚙ Pengaturan -> 🔄 Pembaruan -> "🔄 Cek Update". Aplikasi
   juga memeriksa sendiri sekali sehari saat dibuka. Bila ada versi baru,
   muncul jendela "Versi baru X tersedia" + catatan perubahan + tombol
   untuk membuka halaman unduhan di browser. Cara pasang: unduh ZIP baru,
   tutup HCX STUDIO, ekstrak/timpa folder aplikasi — project, setingan,
   dan lisensi tetap tersimpan.
4. Masker per lapisan (seperti vMix) — pilih lapisan -> bagian
   "🎭 Masker & sensor" di panel Lapisan:
   - Kotak tepi lembut: potong sebagian video dengan tepi yang memudar
     halus ke lapisan di belakangnya. Kelembutan bisa diatur per sisi
     (Kiri / Atas / Kanan / Bawah) atau sekaligus ("Lembut semua sisi").
   - Lingkaran / oval dan Kotak sudut bulat (slider "Sudut bulat"),
     masing-masing dengan "Tepi lembut".
   - Gambar PNG: pilih PNG sendiri; bagian transparan (alpha) atau bagian
     gelap (mode "Terang-gelap": putih = tampil) menjadi masker. Pas:
     Tarik / Utuh / Isi penuh.
   - "Balik (potong bagian dalam)" untuk membalik masker.
   - Klik "✏ Atur area di Preview" lalu geser kotak biru muda (masker)
     atau tarik pojok/sisinya langsung di Preview.
5. Area sensor: "＋ Tambah area sensor" -> kotak Blur atau Piksel (mosaik)
   dengan slider Kekuatan, bisa beberapa area per lapisan (maks. 8),
   digeser/diubah ukurannya di Preview (kotak ungu). Cocok untuk menutup
   wajah, plat nomor, nomor HP, atau logo.
   Masker & sensor tampil sama di Preview, Program, siaran LIVE, rekaman,
   dan output eksternal; tersimpan di project dan di 💾 Setingan. Project
   lama tanpa masker terbuka seperti biasa. Dibuat ringan: masker tepi
   keras cukup memotong (clip), masker lembut/gambar disiapkan sekali dan
   dipakai ulang tiap frame — tetap ringan untuk PC kelas GeForce 940MX.

BARU DI v1.0.1
--------------
1. Klik kanan untuk teks: di kotak isian (stream key, nama, URL, judul,
   dll.) dan pada teks yang diblok, klik kanan memunculkan menu
   Potong / Salin / Tempel / Pilih semua — tidak perlu hafal Ctrl+X/C/V/A.
   Juga berfungsi di dalam jendela Pengaturan, Setingan, dan halaman
   Aktivasi (mis. menempel kunci lisensi).
2. Zoom tampilan: ⚙ Pengaturan -> 🔍 Tampilan -> "Zoom tampilan" 50% - 200%
   (geser slider, tombol － / ＋ per 10%, "↺ 100%" untuk kembali normal).
   Langsung diterapkan dan tetap tersimpan saat aplikasi dibuka lagi.
   Cocok untuk layar kecil/laptop (perkecil) atau layar besar/TV (perbesar).
   Zoom bawaan Ctrl+roda mouse / Ctrl +/- DIKUNCI agar tampilan tidak
   berubah tanpa sengaja saat siaran. Geser lapisan, crop, dan kotak
   "✏ Atur view" di Preview tetap tepat di semua ukuran zoom.
   Zoom tampilan adalah setingan per PC (tidak ikut 💾 Setingan).
3. Layout cepat (Penuh, PiP, 2 Orang, dst.) di panel Scene DIHAPUS.
   Atur posisi kamera langsung di Preview, lalu simpan lewat 💾 Setingan.
4. View kamera kini 6 (sebelumnya 4): 1 Lebar, 2 Dekat, 3 Kiri, 4 Kanan,
   5 Sedang, 6 Wajah (sangat dekat).
   - Tombol 1-6 di panel tengah / Shift+1 .. Shift+6 = ganti view di PROGRAM.
   - Shift+klik tombol = siapkan view di Preview.
   - Nama view bisa diganti: klik dua kali tombol view, atau lewat
     "✏ Atur view" (kolom nama). Nama tersimpan per scene.
   - Project dan file 💾 Setingan lama (4 view) otomatis jadi 6 view;
     view 1-4 Anda tidak berubah, view 5-6 memakai bawaan.
5. Transisi view: pilih "Cut" atau "Zoom" di bawah tombol view.
   - Cut = langsung pindah (kolom durasi disembunyikan).
   - Zoom = zoom halus; kolom "Durasi" muncul (0,1 - 60 detik).
   Setingan lama "zoom 0 detik" otomatis dibaca sebagai Cut.

BARU DI v1.0.0 — HCX STUDIO
---------------------------
1. Nama baru: HCX STUDIO (dulu HC7690 STUDIO), logo baru.
   Program: HCXStudio.exe, folder data: HCXStudio-data.
2. Aplikasi desktop sungguhan (Wails + Microsoft Edge WebView2):
   - Satu jendela aplikasi, tidak ada lagi jendela hitam (log) dan tidak
     perlu Chrome terpasang / Chrome for Testing ±207 MB. Jauh lebih ringan
     untuk PC kentang (memakai mesin Edge yang sudah ada di Windows).
   - Izin kamera, mikrofon, dan layar diberikan otomatis (tidak ada lagi
     banner "Izinkan").
   - Output eksternal (📺 Output) dan semua fitur lama tetap jalan.
   - Menutup jendela saat LIVE/REKAM: aplikasi bertanya dulu; rekaman
     dirapikan jadi MP4 sebelum aplikasi tertutup.
   - Klik 2x HCXStudio.exe saat sudah jalan = jendela yang ada dimunculkan.
3. 💾 SIMPAN SETINGAN (tombol "💾 Setingan" di bar atas):
   - Simpan SELURUH susunan studio dengan nama: scene, sumber, lapisan &
     posisi, overlay 1-4, kotak komentar, daftar lower-third & desain LT,
     soundboard, audio/mixer (volume, mute, delay, AFV, EQ), setingan
     siaran (resolusi, fps, bitrate, encoder, tujuan & stream key),
     rekaman, replay, kota jadwal sholat.
   - ▶ Muat = pakai setingan itu (studio dimuat ulang beberapa detik).
     💾 = timpa dengan kondisi sekarang, ✎ = ganti nama, 🗑 = hapus.
   - ⇩ Ekspor = file .hcxset (setingan + gambar/video/PDF/musik yang
     dipakai) untuk dibawa ke PC lain. ⇧ Impor = buka file .hcxset.
     PERHATIAN: stream key ikut tersimpan — jangan bagikan file itu.
   - "Pulihkan sesi terakhir otomatis saat aplikasi dibuka" (bawaan ON):
     studio dibuka persis seperti saat terakhir ditutup. Matikan bila ingin
     selalu mulai dari studio kosong.
   - Lokasi: HCXStudio-data\presets\ (bisa di-backup).
4. Template scene bawaan DIHAPUS (Pengajian, Lomba 17-an, Podcast, latar
   Virtual Set Berita/Podcast/Pengajian/Talkshow/Studio Modern, dll.).
   Anda membuat scene sendiri lalu menyimpannya lewat 💾 Setingan.
   Virtual Set tetap ada dengan latar gambar/video milik Anda sendiri.
   (Desain lower-third ★ di Desainer LT tetap tersedia sebagai contoh.)
5. Lisensi baru — 1 kunci untuk 1 PC (lihat bagian LISENSI di bawah).
6. Encoder otomatis: NVIDIA NVENC > Intel QuickSync > AMD AMF > x264 (CPU).
   Setiap encoder dites sungguhan (encode singkat) saat aplikasi dibuka,
   jadi GPU yang tidak punya encoder (mis. GeForce 940MX tanpa NVENC) tidak
   akan dipilih. Lihat ⚙ Pengaturan -> Encoder; "Otomatis" memakai yang
   terbaik yang lolos tes.

LISENSI (PRO GRATIS 30 HARI -> VERSI GRATIS / LANGGANAN PRO)
-----------------------------------------------------------
- Pertama kali dibuka, PRO GRATIS 30 HARI langsung mulai dengan SEMUA fitur.
  Sisa hari terlihat di tombol 🔑 (mis. "PRO GRATIS 12 hari").
- Setelah 30 hari (atau saat langganan habis) studio tetap bisa dipakai
  sebagai VERSI GRATIS (badge "FREE"): maks. 720p, 1 tujuan siaran,
  watermark kecil, fitur Pro 🔒. Project, setingan & rekaman tetap aman.
- Paket: Bulanan (30 hari) atau Tahunan (365 hari), 1 PC.
- CARA BERLANGGANAN:
  1) Klik 🔑 di kanan atas (atau tombol Pro pada fitur 🔒). Lihat "ID Mesin PC ini"
     (contoh: HCX-ABCD-EFGH-JKMN-PQRS) -> klik 📋 Salin.
  2) Klik "🛒 Beli Lisensi" — halaman pembelian terbuka di browser dengan
     ID Mesin sudah terisi. Pilih paket Bulanan/Tahunan, lalu bayar.
  3) KUNCI LISENSI (teks panjang diawali HCX1-) dikirim otomatis.
     Salin SEMUA teksnya, tempel di kotak kunci -> ✅ Aktifkan.
     Kunci diperiksa juga ke server lisensi (perlu internet; tanpa
     internet kunci tetap aktif dan dicek ulang saat aplikasi dibuka).
  Butuh bantuan? Klik "💬 Bantuan via WhatsApp" (0852-8875-3044).
- 1 kunci = 1 PC. ID Mesin dihitung dari ID Windows (MachineGuid) + ID
  papan induk (SMBIOS UUID). Instal ulang Windows / ganti motherboard dapat
  mengubah ID Mesin -> hubungi penjual.
- Perpanjangan: tombol "🔄 Perpanjang" muncul 7 hari sebelum habis (dan
  setelah habis) dan membuka halaman pembelian dengan ID Mesin terisi. Kunci
  perpanjangan boleh dimasukkan lebih awal: disimpan dan aktif otomatis pada
  tanggal mulainya.
- Kunci lama HC7690 (HC1- / HC2-) tidak berlaku di HCX STUDIO; minta kunci
  HCX1- baru kepada penjual.
- Hapus folder / ekstrak ulang ZIP TIDAK mengulang masa PRO gratis; lisensi aktif
  otomatis kembali.
- Jangan memundurkan jam/tanggal komputer. Jam mundur > 1 jam saat PRO
  gratis = masa gratis langsung berakhir (menjadi versi Gratis); saat Pro =
  fitur Pro terkunci (versi Gratis tetap jalan) sampai jam Windows
  diperbaiki (Settings -> Time -> Set time automatically).

Isi folder
----------
  HCXStudio.exe      -> program utama (jendela studio + server lokal)
  ffmpeg.exe         -> mesin encoder/pengirim stream (open source, GPL)
  ffmpeg-LICENSE.txt
  HP-Camera\         -> aplikasi kamera HP Android (HCX-Cam.apk) + panduan.
                        Catatan: aplikasi di HP masih bernama "HC7690 Cam"
                        (belum diganti), tetapi tetap tersambung ke HCX STUDIO.
  README.txt         -> file ini
  HCXStudio-data\    -> dibuat otomatis: pengaturan, stream key, project,
                        setingan tersimpan (presets), media, lisensi, log
  Rekaman\           -> hasil rekaman (dibuat otomatis)

Tidak perlu install. Ekstrak ZIP ke folder mana saja (mis. D:\HCX-Studio),
JANGAN dijalankan langsung dari dalam ZIP. Kalau folder tidak bisa ditulisi
(mis. C:\Program Files), data disimpan di %LOCALAPPDATA%\HCXStudio dan
rekaman di Videos\HCX STUDIO.

1. CARA MENJALANKAN
-------------------
1) Klik 2x HCXStudio.exe. Jendela HCX STUDIO terbuka (layar penuh).
   - Kalau Windows SmartScreen muncul ("Windows protected your PC"):
     klik "More info" / "Info selengkapnya" -> "Run anyway".
     (Aplikasi belum ditandatangani digital, jadi wajar muncul.)
   - Kalau antivirus curiga: itu false positive umum untuk program Go
     yang belum bertanda tangan. Tambahkan folder ini ke pengecualian.
   - Belum ada WebView2? Aplikasi memasangnya otomatis (ikuti jendela
     pemasang Microsoft), lalu buka lagi HCXStudio.exe.
2) Pertama kali muncul wizard: bahasa, deteksi spesifikasi PC, dan
   rekomendasi setingan keluaran.
3) Pindahan dari HC7690 STUDIO? Taruh HCXStudio.exe di folder HC7690-Studio
   lama, atau ekstrak folder HCX-Studio bersebelahan dengan folder
   "HC7690-Studio". Saat pertama jalan, pengaturan, stream key, scene &
   sumber (config.json, project.json) dan folder media otomatis disalin
   (file lama tidak dihapus). Gambar latar template lama (folder sets\)
   tidak ikut — ganti dengan gambar sendiri.

Kalau ffmpeg.exe tidak ada di folder, aplikasi menampilkan tombol
"Unduh ffmpeg" (sekitar 100 MB, sekali saja).

Port: studio lokal 127.0.0.1:8765 (hanya PC ini). Remote HP / tally / HP Cam:
8766 (http) dan 8767 (https). Ganti port: HCXStudio.exe -port 9000
-remote-port 9001. Pertama kali remote / HP Cam diaktifkan, izinkan
HCXStudio di Windows Firewall (Private networks), atau klik "🛡 Izinkan di
Firewall Windows" di tab HP Cam.

DARI VERSI SEBELUMNYA (HCX STUDIO v0.8 – v0.9.3), TETAP ADA DI v1.0
=====================================================================

v0.9.3 — OUTPUT EKSTERNAL & RUNNING TEXT DI DESAINER
-------------------------------------------------------------
- 📺 Output eksternal (seperti External Output vMix): tombol "📺 Output"
  di bar atas menampilkan PROGRAM di proyektor / TV / monitor kedua.
  Klik "↻ Deteksi layar" dan pilih "Izinkan" agar output langsung layar
  penuh di layar yang dipilih. Di jendela output: klik dua kali = layar
  penuh, Esc = keluar. Pintasan studio tetap jalan saat jendela output
  aktif. Output tanpa suara (suara tetap dari studio).
- Desainer Lower-third kini bisa membuat RUNNING TEXT: tombol
  "＋ Running text baru", lapisan "＋ Teks berjalan", atau centang
  "🏃 Teks berjalan" pada lapisan teks mana pun (+ atur Kecepatan).
  Isi teksnya lewat kolom
  "Teks berjalan" di panel Lapisan, sama seperti mengisi Nama/Jabatan.
- Durasi zoom view kamera dan durasi fade kini bisa sampai 60 detik
  (sebelumnya maks 10 detik).

v0.9.0 — VIEW KAMERA & MODE CROP
----------------------------------------
- View kamera (Virtual Set 2.0): satu kamera jadi 4 sudut (sejak v1.0.1: 6) (1 Lebar,
  2 Dekat, 3 Kiri, 4 Kanan). Seluruh scene ikut di-zoom/geser, termasuk
  latar virtual set dan meja. Tombol 1-4 di panel tengah (atau Shift+1-4)
  mengganti view di PROGRAM; pilih Cut atau Zoom halus 0,5-3 detik.
  Shift+klik tombol = siapkan view di Preview.
- "✏ Atur view": Preview menampilkan gambar lebar + kotak oranye. Geser
  kotak untuk memindah, tarik pojoknya untuk zoom (maks 4x). Nama view
  bisa diganti; ↺ mengembalikan ke bawaan. Setiap scene punya view sendiri.
  Tips: close-up lebih tajam bila sumber kamera 1080p atau lebih.
- "✂ Mode crop" di judul Preview: pilih lapisan, tarik sisi/pojok hijau
  untuk memotong; sisa gambar tetap di tempat. Tanpa mode ini: tahan Alt
  sambil menarik sisi. Batas crop naik dari 45% ke 90% per sisi.
  "↺ crop" menghapus potongan dan mengembalikan ukuran kotak.
- Virtual set: tombol "↺ Posisi talent" di properti lapisan presenter
  (untuk virtual set yang dibuat di versi ini).

v0.8.2
--------------
- Orientasi gambar HP Camera di studio kini selalu mengikuti HP, termasuk
  saat HP diputar bolak-balik (portrait -> lanskap -> portrait).

v0.8.1
--------------
- Gambar HP Camera di studio tidak lagi macet setelah HP diputar; studio
  menyegarkan sendiri, tanpa perlu mengganti resolusi/mode di HP.

v0.8.0 — HP CAMERA LEBIH STABIL
---------------------------------------
- Kamera native HCX Cam (aplikasi HP: "HC7690 Cam") tidak lagi macet/patah-patah saat HP diputar
  ke lanskap; preview di layar HP kini tegak sesuai posisi HP.
- Jika kamera HP berhenti mengirim gambar, aplikasi membukanya ulang
  otomatis. Jika tetap gagal, HP pindah sendiri ke Mode aman.


2. SETUP IRIUN WEBCAM (HP JADI KAMERA)
--------------------------------------
1) Install "Iriun Webcam" di HP (Play Store / App Store) dan di PC
   (iriun.com). Jalankan dua-duanya.
2) HP dan PC harus di Wi-Fi yang SAMA, atau sambung pakai kabel USB
   (lebih stabil, Android: aktifkan USB debugging sesuai petunjuk Iriun).
3) Di aplikasi Iriun PC pilih resolusi 720p (1280x720). 1080p bikin berat.
4) Di HCX STUDIO: panel Sumber -> klik ⟳ (cari ulang) -> "📷 Kamera"
   -> pilih "Iriun Webcam" -> Tambahkan.
5) Mau 2 HP (podcast 2 orang)? Driver Iriun di Windows biasanya memasang
   beberapa kamera ("Iriun Webcam", "Iriun Webcam #2", dst). Sambungkan
   HP kedua, lalu tambah Kamera kedua dan pilih "#2". (Dukungan multi-HP
   tergantung versi Iriun -- tes dulu sebelum acara.) Lalu di panel Scene
   klik layout "2 Orang" atau "2 Kotak".
6) Iriun juga bisa kirim suara HP (muncul sebagai "Microphone (Iriun
   Webcam)") -> tambahkan lewat "🎤 Mic" kalau mau pakai mic HP.
7) Gambar dari HP biasanya telat ~100-300 ms dibanding suara mic PC.
   Isi kolom "ms" (delay) di strip mic pada panel Audio, mis. 150,
   sampai gerak bibir pas dengan suara.

Mic: pakai mic USB / mic colok / soundcard mixer -> "🎤 Mic".
Untuk mixer/line-in, MATIKAN "peredam bising".



3. CARA PAKAI SINGKAT
---------------------
- PREVIEW (kiri, hijau) = scene yang sedang disiapkan.
  PROGRAM (kanan, merah) = yang ditonton penonton.
- Panel Scene: klik = masuk Preview. Klik 2x = langsung tayang.
- Tombol CUT (ganti langsung), FADE (memudar), FTB (layar hitam).
- Keyboard: 1-9 pilih scene ke Preview, SPASI = transisi,
  C = cut, F = fade, B = layar hitam,
  Ctrl+1..Ctrl+4 atau F1..F4 = Overlay 1-4 ON/OFF,
  Alt+1..Alt+9 = tombol soundboard (bisa diganti), R = instant replay,
  Shift+1..Shift+6 = view kamera 1-6,
  PageDown / PageUp atau panah Kanan / Kiri = halaman PDF berikut / sebelum
  (hanya saat TIDAK sedang mengetik di kotak isian).
- Panel Sumber: tambah Kamera, Mic, Layar (share layar/jendela/PPT),
  Gambar/Logo (PNG/JPG, bisa jadi logo pojok kanan atas), Video (MP4),
  Teks (lower-third nama+jabatan, judul, teks berjalan), Warna latar.
  Tombol ＋ di samping sumber = masukkan ke scene preview.
- Panel Lapisan: urutan, tampil/sembunyi, posisi. Di Preview bisa
  geser pakai mouse; tarik kotak biru di pojok kanan bawah untuk ubah
  ukuran (tahan Shift = bebas rasio).
- v1.0: tidak ada lagi template scene bawaan. Buat scene sendiri (＋), lalu
  simpan seluruh susunan studio lewat 💾 Setingan (lihat di atas).
- Audio: volume per sumber, mute, meter suara, delay (ms), AFV
  (audio ikut video: suara video/layar hanya keluar kalau sedang tayang).
  🎧 monitor = dengar hasil mix (pakai headset biar tidak ngiung).

OVERLAY (mirip vMix) — bar "OVERLAY" di bawah Preview/Program:
- 4 saluran: Overlay 1-4. Isinya "standby" di atas Program dan TIDAK
  ikut berubah waktu ganti scene. Cocok untuk logo, running text,
  lower-third nama pembicara, atau kamera kecil (PiP).
- Pilih sumber di kotak tiap saluran (sumber apa saja: teks, gambar,
  kamera, video, layar). Sumber tidak perlu dimasukkan ke scene.
- Tombol OV1..OV4 = ON/OFF. Merah + "ON AIR" = sedang tayang.
  Keyboard: Ctrl+1..4 atau F1..F4.
- Transisi per saluran: Cut (langsung) atau Fade + durasi (ms).
- Urutan tumpukan: Overlay 1 paling bawah, Overlay 4 paling atas.
  FTB (layar hitam) menutup overlay juga.
- Tombol ✎ = atur posisi/ukuran/transparansi. Overlay tampil oranye
  (bayangan) di Preview, geser/ubah ukuran seperti lapisan scene.
- "tampil di Preview": overlay yang ON ikut terlihat di Preview.
- Saat aplikasi dibuka ulang, sumber & posisi overlay diingat, tapi
  semua saluran mulai OFF (supaya tidak ada yang tayang sendiri).
- "semua OFF" = matikan semua overlay sekaligus.

TRANSPARANSI (0-100%, 100% = tidak tembus):
- Pilih lapisan / overlay -> bagian "Transparansi" di panel Lapisan.
- Lower-third: "Kotak latar" (kotak + garis aksen) dan "Teks" terpisah.
- Running text: "Bar latar" dan "Teks" terpisah.
- Teks biasa: "Latar" dan "Teks".
- LT Desain (Desainer lower-third, termasuk template ★): "Kotak/Latar"
  (semua kotak, garis aksen & gambar) dan "Teks" terpisah. (v0.5: sudah
  diperbaiki — di v0.4 slider-nya tidak berpengaruh.)
- Jam / Jadwal sholat: "Latar" dan "Teks".
- Daftar lower-third: slider transparansi juga ada langsung di tab 📋 LT.
- Gambar/Logo (dan kamera/video/warna): "Opasitas".
- Geser slider atau ketik angka. Langsung terlihat di Preview & Program.



REKAMAN MP4 LENGKAP DI WINDOWS EXPLORER
---------------------------------------File rekaman sekarang MP4 yang "rapi": klik kanan -> Properties ->
Details menampilkan semuanya (Frame width/height, Frame rate, Data rate,
Total bitrate, Length, Audio bit rate, Channels, Audio sample rate).
- Selama merekam, file ditulis aman (format MKV, tahan listrik mati).
  Saat REKAM/LIVE dihentikan, file otomatis dirapikan jadi MP4 (tanpa
  mengurangi kualitas, beberapa detik). Tunggu tulisan "Rekaman
  tersimpan" sebelum membuka file.
- Kalau listrik mati / aplikasi tertutup saat merekam, rekaman otomatis
  dirapikan waktu aplikasi dibuka lagi.
- Format bawaan sekarang MP4 (setting lama MKV dipindah ke MP4 sekali).
  Masih bisa pilih MKV di Pengaturan, tapi detail MKV di Explorer bisa
  tidak lengkap.



FITUR LENGKAP
=============

H. 🎨 DESAINER LOWER-THIRD (mirip GT Title Designer vMix)
---------------------------------------------------------
Tab 📋 LT -> "🎨 Desainer LT" (atau tombol 🎨 Desainer di panel Lapisan).
- Lapisan: ＋ Teks, ＋ Kotak (bisa sudut bulat & gradasi 2 warna), ＋ Gambar /
  logo (PNG/JPG maks 3 MB, disimpan di dalam template).
- Klik lapisan di gambar -> geser pakai mouse, tarik kotak biru = ubah ukuran
  (Shift = jaga rasio). Urutan: ▲ ▼ di daftar lapisan (atas = paling depan),
  👁 sembunyi, ✕ hapus. Angka X/Y/L/T dalam persen.
- Teks: font (Poppins, Montserrat, Oswald, Bebas Neue, Lora, Amiri — semua
  ikut di aplikasi, tidak butuh internet), ukuran, tebal, miring, KAPITAL,
  bayangan, rata kiri/tengah/kanan, "kecilkan bila panjang".
- KOLOM: isi "Kolom" pada lapisan teks (mis. Nama, Jabatan, Asal). Daftar
  lower-third mengisi kolom pertama dengan Nama, kolom kedua dengan Jabatan;
  kolom ke-3 dst. ditanya saat ✎ ubah item.
- "Peran" (Latar / Aksen / Teks) dipakai tombol Tema warna.
- 💾 Simpan (template bawaan ★ disimpan sebagai salinan baru),
  📋 Pakai di daftar LT, ＋ Sumber (jadi sumber biasa / overlay).
- ⇩ Ekspor = simpan file .hclt.json untuk dibawa ke PC lain (gambar ikut di
  dalam file). ⇧ Impor = buka file itu di PC lain.
- Desain LT contoh (★, bisa diubah / dihapus dari daftar Anda): Berita Klasik, Pengajian Emas, Pita Modern,
  Podcast Kapsul, Lomba 17-an.

I. ✨ ANIMASI LOWER-THIRD & TEMA WARNA
-------------------------------------
- Setiap Overlay (dan daftar LT) punya animasi MASUK dan KELUAR: Cut, Fade,
  Geser dari kiri, Geser dari kanan, Naik dari bawah, Wipe, Zoom + durasi (ms).
  Di bar Overlay: kotak pertama = masuk, kedua = keluar ("= masuk" = sama).
  Di tab 📋 LT ada pengaturan yang sama untuk saluran lower-third.
- Berlaku untuk semua isi overlay: LT desain, lower-third lama, logo, skor, dll.
- Tema warna (Biru Berita, Hijau Masjid, Merah Putih, Hitam Emas, Ungu Podcast,
  Putih Bersih): klik di tab 📋 LT -> berlaku untuk lower-third yang dipakai.

J. 🕌 JAM, TANGGAL & JADWAL SHOLAT
---------------------------------
Panel Sumber -> 🕌 Jam/Sholat. Tampilan: Jam + tanggal ("Jumat, 9 Oktober
2026"), Jadwal sholat (satu baris, waktu berikutnya disorot), Sholat
berikutnya + hitung mundur ("Menuju Ashar 14:42 — 40:35"), atau lengkap.
- Dihitung OFFLINE (tanpa internet) dengan cara Kemenag: Subuh 20°, Isya 18°,
  Ashar bayangan 1x (Syafi'i), ihtiyat 2 menit, Imsak = Subuh − 10 menit.
  Hari Jumat, Dzuhur ditulis "Jumat". Dicek terhadap jadwal resmi Bimas Islam
  Kab. Bekasi Oktober 2026: semua waktu sama atau selisih maksimal 1 menit.
- Kota bawaan: Kab. Bekasi. "✎ daftar kota" = tambah / ubah kota sendiri
  (lintang, bujur, WIB/WITA/WIT). Koordinat bisa dilihat di Google Maps.
- Jam memakai jam komputer -> pastikan jam & zona waktu Windows benar.
- Tampilkan lewat Overlay (paling enak) atau masukkan ke scene.
  Tetap cocokkan dengan jadwal masjid setempat; masjid kadang menambah menit.

K. 🎵 MUSIK LATAR + AUTO DUCKING
-------------------------------
Panel Sumber -> 🎵 Musik (atau tab 🎵 Musik -> ＋ Musik latar), pilih lagu
(MP3/M4A/OGG/WAV, boleh banyak; file disalin ke folder media).
- ▶/⏸, ⏮ ⏭, ulang, acak. Volume musik = strip di panel Audio.
- Auto ducking: saat mic (pilih mic tertentu atau semua) melewati "Ambang",
  musik diturunkan sebesar "Turunkan musik" (dB). Attack = seberapa cepat
  turun, Release = seberapa cepat naik lagi, Tahan = jeda sebelum naik.
  Status "mic −20 dB → musik −15 dB (DUCK)" tampil di tab 🎵 Musik.
  Mulai dari: ambang −38 dB, turunkan 15 dB, attack 80 ms, release 900 ms.

L. 🔊 SOUNDBOARD (JINGLE / EFEK SUARA)
-------------------------------------
Tab 🎵 Musik, bagian bawah. ＋ pad -> pilih file suara, nama, volume, hotkey
(klik kotak hotkey lalu tekan tombol; bawaan Alt+1 … Alt+9; tombol yang dipakai
studio seperti Spasi, C, F, B, R, 1-9, F1-F4 ditolak), loop, warna.
- Klik pad = bunyi (klik lagi = ulang dari awal; pad loop: klik lagi = berhenti).
- ■ STOP SEMUA = hentikan semua suara. Slider volume = volume soundboard.
- Suara soundboard ikut ke siaran DAN rekaman. Maks 12 pad.

M. 📼 PLAYLIST VIDEO STANDBY
---------------------------
Panel Sumber -> 📼 Playlist -> pilih beberapa video (opening, iklan sponsor,
video jeda). Masukkan ke scene seperti video biasa (bisa chroma key juga).
- Diputar berurutan otomatis; video berikutnya disiapkan di belakang jadi
  pergantian tanpa layar hitam. "ulang (loop)" = kembali ke video pertama.
  Tanpa loop, di akhir: tahan frame terakhir / kembali ke awal / kosong.
- Atur urutan, hapus, ⏮ ⏯ ⏭, klik judul = langsung putar (panel Lapisan).
- Beda dengan 🎞 Video: file DISALIN ke folder media (maks 200 MB per file),
  jadi tetap ada saat aplikasi dibuka ulang.

N. ⏪ INSTANT REPLAY
------------------
Tab ⏪ Replay -> centang "Buffer replay aktif". Aplikasi terus menyimpan
10-30 detik terakhir gambar Program (termasuk overlay/skor) di memori.
- Tombol 5/8/10/15/30 dtk atau tombol R = putar ulang, lalu OTOMATIS kembali
  LIVE. Kecepatan Normal / Lambat 50% / Super lambat 25%.
- Selama replay penonton melihat tulisan "⏪ REPLAY" (bisa dimatikan); suara
  mic tetap live (suara tidak di-replay). Overlay & kotak komentar tetap di atas.
- Kualitas replay 360p/480p/540p (diperbesar ke resolusi output) supaya ringan;
  memori dibatasi maks ±64 MB. Matikan buffer kalau PC terasa berat.

O. ✅ CEK SIAP LIVE
------------------
Tombol "✅ Cek siap LIVE" di atas. Mengecek dan memberi hasil ✔ / ⚠ / ✖ +
saran perbaikan:
  - stream key & URL tujuan terisi, ffmpeg ada,
  - server YouTube/Facebook bisa dihubungi (jabat tangan RTMP; stream key
    TIDAK dikirim),
  - kecepatan upload (kirim ±3 MB data acak ke speed.cloudflare.com) vs bitrate
    yang dipakai (butuh ±1,5x bitrate × jumlah tujuan),
  - suara mic terdeteksi (bicara ke mic selama ±3 detik tes), tidak mute,
    tidak pecah,
  - kamera aktif & tidak hitam,
  - ruang disk untuk rekaman (perkiraan jam rekaman).
Cek ini tidak menjamin siaran lancar (internet bisa berubah), tapi menangkap
kesalahan umum sebelum acara.


Q. 💬 KOTAK KOMENTAR BISA DIGESER
--------------------------------
Tab 💬 Komentar -> "Atur tampilan" -> "✥ geser di Preview": kotak komentar
tampil (oranye) di Preview, geser pakai mouse, tarik pojok kanan bawah untuk
ubah ukuran. Angka X/Y/L/T dan tombol posisi cepat (↙ ↘ ↖ tengah) ada di
panel Lapisan. "Selesai" untuk menutup.



B. 🎬 VIRTUAL STUDIO (CHROMA KEY / GREEN SCREEN)
------------------------------------------------
Butuh: kain/layar HIJAU (atau biru) polos di belakang orang, cahaya rata
(tidak ada bayangan & kerutan), orang tidak memakai baju hijau.

Chroma key di kamera / video / layar:
  1) Pilih lapisan kamera (panel Lapisan atau klik di Preview).
  2) Centang "Chroma key (green screen)".
  3) Klik "💧 Ambil dari Preview" lalu klik bagian latar hijau di Preview
     (atau tombol Hijau / Biru, atau pilih warna sendiri).
  4) Atur:
     - Kemiripan  : makin besar = makin banyak warna mirip hijau yang dibuang.
                    Naikkan kalau latar masih kelihatan; turunkan kalau
                    badan/rambut ikut bolong.
     - Kehalusan  : pinggiran lebih halus (tidak bergerigi).
     - Buang pantulan hijau : menghilangkan sisa hijau di rambut/pinggir badan.
     - Potong (crop) kiri/kanan/atas/bawah : buang pinggir kain/tiang lampu.
  Pakai kartu grafis (WebGL). Kalau WebGL tidak ada, otomatis pakai mode
  CPU (resolusi diturunkan, lebih berat). Kalau PC terlalu berat, aplikasi
  otomatis menurunkan resolusi chroma key ke 640 px (ada pesan di log).

🎬 Virtual Set (panel Sumber -> tombol 🎬 Virtual Set):
  - Pilih latar: "Gambar / video sendiri" (JPG/PNG/MP4). (v1.0: latar
    bawaan dihapus — pakai gambar/video latar milik Anda sendiri.)
  - Pilih kamera Orang 1 (dan Orang 2 untuk 2 orang), posisi (tengah /
    kiri / 2 orang), centang "meja di depan presenter" (Berita, Podcast,
    Pengajian punya meja), centang "layar saya BIRU" kalau perlu.
  - Klik "Buat scene" -> scene baru "Virtual: ..." masuk Preview, chroma key
    kamera otomatis aktif. Rapikan pakai "Kemiripan" seperti di atas.
  Sejak v0.4 chroma key melekat ke LAPISAN di scene (bukan ke sumber):
  kamera yang sama bisa ter-key di scene Virtual Set tapi tampil normal di
  scene lain. Tombol "Salin ke N lapisan lain" = pakai setelan yang sama di
  semua scene. Potong (crop) tetap per sumber (berlaku di semua scene).


C. 📄 PDF (SLIDE / MATERI)
--------------------------
Panel Sumber -> 📄 PDF -> pilih file. PowerPoint? Simpan dulu "Save as PDF".
- File disalin ke folder HCXStudio-data\media (maks ±200 MB).
- Halaman digambar setajam resolusi output. Halaman sebelum & sesudah
  disiapkan di belakang, jadi ganti halaman langsung tanpa kedip.
- Ganti halaman: ◀ ▶ di daftar Sumber / panel Lapisan, ketik nomor
  halaman, keyboard PageDown/PageUp atau panah Kanan/Kiri (saat tidak
  mengetik), atau dari remote HP.
  Kalau ada beberapa PDF, keyboard mengatur PDF yang sedang TAYANG;
  kalau tidak ada yang tayang, PDF di Preview / yang terakhir dipakai.
- "Pas": Utuh (fit, ada pinggiran) atau Isi penuh (fill, terpotong).
- Bisa dipakai di scene maupun sebagai sumber Overlay 1-4.
- Font khusus & huruf Arab/Asia ikut terbaca (pdf.js + cmaps sudah
  dibundel, tanpa internet).


D. 💬 KOMENTAR LIVE DI LAYAR
----------------------------
Tab 💬 Komentar.
YouTube (tanpa API key, tanpa login):
  - Tempel link siaran live (https://www.youtube.com/watch?v=..., youtu.be/...,
    youtube.com/live/...) atau link channel (https://www.youtube.com/@nama/live
    atau cukup @nama) -> Sambung.
  - Siaran harus SEDANG LIVE dan chat-nya aktif (bukan "khusus member").
    Komentar masuk tiap ±2-10 detik (sama seperti chat di YouTube).
  - Pesan "chat dimatikan" / "YouTube membatasi akses" -> cek siaran, atau
    tunggu beberapa menit lalu Sambung lagi.
  - Cara ini memakai halaman chat publik YouTube; kalau YouTube mengubah
    sistemnya, fitur ini bisa berhenti sampai aplikasi diperbarui.
    Cadangan: "ketik komentar sendiri".
Facebook (butuh token):
  - Facebook tidak mengizinkan membaca komentar tanpa token. Isi:
    "ID video live" (angka di link video, mis. facebook.com/.../videos/1234567890)
    dan "Page access token" (token HALAMAN dengan izin pages_read_engagement,
    buat di developers.facebook.com -> Graph API Explorer). Token disimpan di
    config.json seperti stream key -> jangan dibagikan.
  - Tanpa token: bagian Facebook menampilkan "butuh token", pakai ketik sendiri.
Ketik komentar sendiri: isi Nama + komentar (mis. dari WhatsApp / SMS),
  Enter = masuk daftar, Ctrl+Enter / "Tampil" = langsung tayang.
Menampilkan:
  - Klik komentar di daftar -> muncul di Program sebagai kotak komentar
    (nama, foto profil kalau ada, logo YouTube/Facebook, isi komentar).
    Klik lagi = sembunyikan. Tombol TAMPILKAN / SEMBUNYIKAN juga ada.
  - Fade / Cut, "auto hilang" (detik, 0 = tidak otomatis), dan
    "Atur tampilan": gaya (Kartu / Gelembung / Bar), posisi (↙ ↘ ↖ tengah),
    warna latar & aksen, transparansi, foto on/off.
  - Kotak komentar ada di atas Overlay 1-4 dan di bawah FTB; ikut ke siaran
    & rekaman. Saat aplikasi dibuka ulang kotak komentar mulai OFF.
  - Foto profil diambil lewat aplikasi (localhost), tidak ada server lain.


E. 📋 DAFTAR LOWER-THIRD
------------------------
Tab 📋 LT: isi Nama + Jabatan -> ＋ (atau "📋 Tempel banyak": satu baris
satu orang "Nama | Jabatan"). Klik nama = lower-third langsung tampil,
klik lagi = sembunyi. Pakai satu sumber lower-third ("LT: Daftar", dibuat
otomatis — gaya/warna/transparansinya bisa diatur seperti lower-third biasa)
lewat Overlay pilihan ("Tampil di": otomatis = overlay kosong pertama).


F. 🏆 PAPAN SKOR & TIMER
------------------------
Panel Sumber -> 🏆 Skor / ⏱ Timer (atau tombol di tab 🏆 Skor).
- Papan skor: 2 tim (nama, warna, skor), babak/set opsional, gaya Bar /
  Kotak / Mini. Tombol − / + besar di tab 🏆 Skor (skor tidak bisa minus).
- Timer: Hitung mundur ("Acara dimulai dalam 05:00", setelah habis tampil
  teks penutup, mis. "Acara segera dimulai!") atau Stopwatch.
  ▶ Mulai / ⏸ Jeda / ⟲ Reset. Gaya: Kotak + judul, Satu baris, Angka besar.
  Timer tetap benar walau halaman di-refresh.
- Posisi, ukuran, transparansi (Latar / Teks) diatur seperti lapisan lain;
  tampilkan lewat Overlay 1-4 (paling enak) atau masukkan ke scene.
- Semua bisa dikendalikan dari remote HP.


G. 📱 REMOTE DARI HP + TALLY (LAMPU KAMERA)
------------------------------------------
1) Tab 📱 Remote -> "AKTIFKAN REMOTE HP".
   PERTAMA KALI Windows menampilkan "Windows Defender Firewall has blocked
   some features": centang "Private networks", klik "Allow access".
   (Kalau terlanjur Cancel: Control Panel -> Windows Defender Firewall ->
   Allow an app -> centang HCXStudio untuk Private.)
   Jaringan Wi-Fi di Windows sebaiknya diset "Private", bukan "Public".
2) HP & PC harus di Wi-Fi/router yang SAMA. Scan QR di layar dengan kamera
   HP, atau ketik alamatnya (mis. http://192.168.1.5:8766/remote).
3) Masukkan PIN 6 angka yang tampil di studio. 5x salah = dikunci 1 menit.
   Tombol ↻ di sebelah PIN = PIN baru (HP lama harus masuk ulang).
Remote bisa: pilih scene ke Preview, CUT / FADE / FTB, Overlay 1-4 ON/OFF,
halaman PDF ◀ ▶, komentar (pilih / tampil / sembunyi), skor − / +, timer,
lower-third dari daftar (termasuk desain dari Desainer LT).
v0.4: soundboard (pad + STOP SEMUA), instant replay (5/10/15 detik, lambat
50%/25%, kembali LIVE), playlist video standby (⏮ ⏯ ⏭), musik latar (⏯ ⏭,
ducking ON/OFF), jam / jadwal sholat & LT desain ON/OFF lewat overlay.
TALLY: di HP kameramen buka http://<alamat>:8766/tally -> PIN -> pilih
kamera -> "Mulai tally". Layar HP MERAH = kamera itu sedang tayang
(Program), HIJAU = di Preview (siap), hitam = tidak dipakai. Ketuk 2x untuk
ganti kamera. Atur HP supaya layar tidak mati sendiri.
Keamanan: studio utama tetap hanya bisa dibuka dari PC ini. Dari jaringan
hanya halaman remote/tally yang terbuka, dan wajib PIN. Remote mati lagi
kalau tombol MATIKAN diklik (status diingat saat aplikasi dibuka ulang).
Port remote bisa diganti: HCXStudio.exe -remote-port 9001
Tidak bisa tersambung? Wi-Fi tamu/hotspot kantor kadang memblokir antar
perangkat ("AP isolation") -> pakai hotspot HP sendiri atau router rumah.



4. SETTING YOUTUBE / FACEBOOK
-----------------------------
YouTube:
  1) Buka studio.youtube.com -> Buat (ikon kamera) -> Mulai siaran
     langsung -> tab "Streaming" / "Live sekarang".
     (Akun baru: verifikasi nomor HP, tunggu sampai 24 jam aktif.)
  2) Salin "Kunci streaming" (stream key).
  3) Di HCX STUDIO: ⚙ Pengaturan -> centang YouTube -> tempel di
     "Stream key". URL server biarkan: rtmp://a.rtmp.youtube.com/live2
  4) Klik "● LIVE". Di YouTube Studio tunggu status "Sangat baik".
Facebook:
  1) facebook.com/live/producer -> "Software streaming" / "Gunakan kunci
     stream" -> salin Kunci stream.
  2) ⚙ Pengaturan -> centang Facebook -> tempel kunci.
     URL: rtmps://live-api-s.facebook.com:443/rtmp/
Bisa YouTube + Facebook sekaligus, tapi butuh upload internet 2x lipat.

Stream key disimpan di HCXStudio-data\config.json (hanya di komputer
ini). Jangan kirim folder ini ke orang lain tanpa menghapus config.json.

REKAM: tombol "⏺ REKAM" = rekam saja tanpa siaran. Mau rekam sambil live:
centang "Rekam juga saat LIVE" di Pengaturan. File masuk ke folder
"Rekaman" sebagai MP4 lengkap (direkam aman dulu, dirapikan saat
berhenti — lihat bagian v0.6).



5. REKOMENDASI SETTING (PC LEMAH / INTERNET LEMAH)
--------------------------------------------------
Cek dulu kecepatan UPLOAD internet di fast.com / speedtest.net.
Bitrate video sebaiknya maksimal ~60-70% dari kecepatan upload.

  Upload < 2 Mbps   -> 480p 30fps, video 1000 kbps, audio 96 kbps
  Upload 3-5 Mbps   -> 720p 30fps, video 2500 kbps, audio 128 kbps  (DISARANKAN)
  Upload > 8 Mbps   -> 1080p 30fps, video 4500 kbps (butuh PC kuat)

Di Pengaturan ada "Preset cepat" untuk tiga pilihan di atas.

PC kentang (dual-core, RAM 4 GB):
  - Pakai 480p atau 720p, 30 atau 25 fps.
  - Mode video "Otomatis" (copy H.264 dari browser = paling hemat CPU).
  - FPS preview 5, atau matikan centang "tampilkan" di Preview.
  - Kamera Iriun set 720p, jangan 1080p.
  - Tutup aplikasi lain (game, banyak tab Chrome, WhatsApp desktop).
  - Laptop: colok charger, power mode "Best performance".
  - Pakai kabel LAN kalau bisa, bukan Wi-Fi.
  - Chroma key: pakai kamera 720p; kalau berat aplikasi otomatis menurunkan
    resolusi key. Jangan nyalakan chroma key di kamera yang tidak perlu.
  - Kalau PC tidak kuat, aplikasi melewati frame (fps turun) supaya
    tombol tetap responsif — tanda bahwa setting perlu diturunkan.
Kalau angka "antrian" di atas terus naik / warna kuning: internet atau
CPU tidak kuat -> turunkan bitrate atau resolusi.
Kalau "Mode video: Otomatis" bermasalah (gambar macet / YouTube bilang
keyframe jarang), ganti ke "Encode ulang" (pakai GPU Intel/NVIDIA/AMD
kalau terdeteksi, kalau tidak pakai x264 CPU "ultrafast").



6. MASALAH UMUM
---------------
- Kamera tidak muncul: buka aplikasi Iriun di HP & PC dulu, lalu klik ⟳.
  Pastikan kamera tidak dipakai Zoom/OBS/aplikasi lain.
- Layar hitam di kamera: klik ⟳ di samping sumber (sambung ulang).
- Tidak ada suara di siaran: cek meter MASTER bergerak, cek mute,
  cek AFV (kalau AFV aktif, suara hanya keluar saat sumbernya tayang).
- Share layar tanpa suara: saat memilih layar/tab, centang
  "Bagikan audio sistem / Share audio".
- Siaran putus: aplikasi sambung ulang otomatis (maks 10x). Kalau
  rekaman aktif, rekaman berikutnya jadi file baru.
- Port 8765 terpakai: aplikasi otomatis cari port berikutnya.
  Bisa juga: HCXStudio.exe -port 9000
- Klik 2x HCXStudio.exe padahal sudah jalan: tidak dobel, jendela yang
  sudah terbuka dimunculkan.
- Jangan minimize jendela studio terlalu lama di PC sangat lemah;
  aplikasi tetap jalan di belakang, tapi lebih aman jendelanya dibiarkan
  terbuka (boleh ditutupi jendela lain).
- Log lengkap: file HCXStudio-data\hcxstudio.log, dan tombol "Log"
  di kanan bawah aplikasi.


7. CATATAN TEKNIS
-----------------
Alur: kamera/mic -> mesin WebView2 menggabungkan scene di canvas & mix audio
-> MediaRecorder -> WebSocket lokal -> HCXStudio.exe -> ffmpeg.exe -> RTMP
(YouTube/FB/TikTok, satu encode untuk semua tujuan) + file rekaman.
Overlay, kotak komentar, skor/timer, PDF & chroma key digambar di canvas
Program yang sama, jadi otomatis ikut ke siaran & rekaman.
Komentar YouTube/Facebook diambil HCXStudio.exe langsung dari YouTube /
Facebook (tidak lewat server pihak ketiga). Nama file rekaman:
HCXStudio_TANGGAL_JAM.mp4. Log: HCXStudio-data\hcxstudio.log dan tombol
"Log" di kanan bawah aplikasi.

Komponen pihak ketiga: Wails v2 (MIT), Microsoft Edge WebView2 Runtime
(Microsoft), gorilla/websocket (BSD), ffmpeg dari https://www.gyan.dev
(GPL, lihat ffmpeg-LICENSE.txt; source: https://ffmpeg.org), pdf.js 4.10.38
(Apache-2.0), qrcode-generator (MIT), font Poppins, Montserrat, Oswald,
Bebas Neue, Lora, Amiri (SIL OFL 1.1). Tes upload di "Cek siap LIVE"
memakai speed.cloudflare.com (hanya saat tombol diklik).
